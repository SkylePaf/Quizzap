const LOADER_MIN_DURATION_MS   = 800;
const LOADER_FRAME_INTERVAL_MS = 50;

const STORAGE_KEY_CREATED = "quizzap_quizzes_created";
const STORAGE_KEY_EDIT    = "quizzap_edit_quiz";
const STORAGE_KEY_SOURCE  = "quizzap_edit_source";
const STORAGE_KEY_PLAY    = "quizzap_play_quiz";

const loaderStates = [
    ["","",""],[".",  "",""],["..","",""],["...","",""],
    ["...",".",""],[  "...","..",""],["...","...",""],
    ["...","...","."],[  "...","..",".."],["...","...","..."],
    ["..","...","..."],[  ".","...","..."],["","...","..."],
    ["","..","..."],[  "",".",  "..."],["","","..."],
    ["","",".."],["","","."],["","",""]
];

let running         = { value: true };
let seconds_passed  = false;
let pageLoaded      = false;
let loaderSections;
let notifTimeout;
let pendingDeleteId = null;

const notification   = document.getElementById("notification");
const confirmModal   = document.getElementById("confirm_modal");
const quizGrid       = document.getElementById("quiz_grid");
const emptyState     = document.getElementById("empty_state");
const quizCountBadge = document.getElementById("quiz_count_badge");

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

async function runLoader(state) {
    let i = 0;
    while (state.value) {
        const [s1, s2, s3] = loaderStates[i % loaderStates.length];
        loaderSections.l1.textContent = s1;
        loaderSections.l2.textContent = s2;
        loaderSections.l3.textContent = s3;
        i++;
        await sleep(LOADER_FRAME_INTERVAL_MS);
    }
}

function hideLoaderIfReady() {
    if (seconds_passed && pageLoaded) {
        running.value = false;
        const loader = document.getElementById("loader");
        loader.style.opacity       = "0";
        loader.style.pointerEvents = "none";
    }
}

function showNotification(message, type = "info") {
    notification.textContent     = message;
    notification.className       = `Notification ${type}`;
    notification.style.opacity   = "1";
    notification.style.transform = "translateX(-50%) translateY(0)";
    clearTimeout(notifTimeout);
    notifTimeout = setTimeout(() => {
        notification.style.opacity   = "0";
        notification.style.transform = "translateX(-50%) translateY(20px)";
    }, 2800);
}

function getQuizzes() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY_CREATED) || "[]");
}

function saveQuizzes(quizzes) {
    localStorage.setItem(STORAGE_KEY_CREATED, JSON.stringify(quizzes));
}

function formatDate(iso) {
    if (!iso) return "—";
    return new Date(iso).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function createCard(quiz, index) {
    const card       = document.createElement("div");
    card.className   = "QuizCard";
    card.dataset.id  = quiz.id;

    const count = quiz.questions?.length || 0;
    const date  = formatDate(quiz.modifiedAt || quiz.createdAt);

    card.innerHTML = `
        <div class="CardHeader">
            <p class="CardTitle">${quiz.name || "Quizz sans titre"}</p>
            <button class="CardDeleteBtn" title="Supprimer">✕</button>
        </div>
        <div class="CardBody">
            <p class="CardMeta"><span>${count}</span> question${count > 1 ? "s" : ""}</p>
            <p class="CardMeta">modifié le <span>${date}</span></p>
        </div>
        <div class="CardFooter">
            <button class="CardAction play">jouer</button>
            <button class="CardAction edit">modifier</button>
            <button class="CardAction download">télécharger</button>
        </div>
    `;

    card.querySelector(".CardDeleteBtn").addEventListener("click", (e) => {
        e.stopPropagation();
        pendingDeleteId                  = quiz.id;
        confirmModal.style.opacity       = "1";
        confirmModal.style.pointerEvents = "all";
    });

    card.querySelector(".CardAction.play").addEventListener("click", (e) => {
        e.stopPropagation();
        localStorage.setItem(STORAGE_KEY_PLAY, JSON.stringify(quiz));
        window.open("../QuizzPlayer/QuizzPlayer.html", "_self");
    });

    card.querySelector(".CardAction.edit").addEventListener("click", (e) => {
        e.stopPropagation();
        localStorage.setItem(STORAGE_KEY_EDIT, JSON.stringify(quiz));
        localStorage.setItem(STORAGE_KEY_SOURCE, "created");
        window.open("../QuizzCreator/QuizzCreator.html", "_self");
    });

    card.querySelector(".CardAction.download").addEventListener("click", (e) => {
        e.stopPropagation();
        const blob = new Blob([JSON.stringify(quiz, null, 2)], { type: "application/json" });
        const url  = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href     = url;
        link.download = `${quiz.name || "quizz"}.json`;
        link.click();
        URL.revokeObjectURL(url);
        showNotification("Téléchargement...", "success");
    });

    setTimeout(() => card.classList.add("visible"), 10 + index * 40);
    return card;
}

function renderQuizzes() {
    quizGrid.querySelectorAll(".QuizCard").forEach(c => c.remove());

    const quizzes = getQuizzes();
    quizCountBadge.textContent = `${quizzes.length} quizz`;

    if (quizzes.length === 0) {
        emptyState.style.display = "flex";
        return;
    }

    emptyState.style.display = "none";
    quizzes.forEach((quiz, i) => quizGrid.appendChild(createCard(quiz, i)));
}

document.getElementById("back_button").addEventListener("click", () => {
    window.open("../../index.html", "_self");
});

document.getElementById("go_create_btn").addEventListener("click", () => {
    window.open("../QuizzCreator/QuizzCreator.html", "_self");
});

document.getElementById("confirm_yes").addEventListener("click", () => {
    if (!pendingDeleteId) return;
    saveQuizzes(getQuizzes().filter(q => q.id !== pendingDeleteId));
    pendingDeleteId                  = null;
    confirmModal.style.opacity       = "0";
    confirmModal.style.pointerEvents = "none";
    renderQuizzes();
    showNotification("Quizz supprimé", "error");
});

document.getElementById("confirm_no").addEventListener("click", () => {
    pendingDeleteId                  = null;
    confirmModal.style.opacity       = "0";
    confirmModal.style.pointerEvents = "none";
});

document.addEventListener("DOMContentLoaded", () => {
    loaderSections = {
        l1: document.getElementById("l1"),
        l2: document.getElementById("l2"),
        l3: document.getElementById("l3")
    };
    runLoader(running);
    sleep(LOADER_MIN_DURATION_MS).then(() => {
        seconds_passed = true;
        hideLoaderIfReady();
    });
});

window.addEventListener("load", () => {
    pageLoaded = true;
    hideLoaderIfReady();
    renderQuizzes();
});